package PP20_4;

public class SavingsSimulationViewer {
	public static void main(String[] arg)
	{
		new SavingsSimulation();
	}
}

/*
Initial Value: $10000.0| Every * is $500
Year: 1| Bal: *********************
Year: 2| Bal: ***********************
Year: 3| Bal: ************************
Year: 4| Bal: *************************
Year: 5| Bal: **************************
Year: 6| Bal: ***************************
Year: 7| Bal: *****************************
Year: 8| Bal: ******************************
Year: 9| Bal: ********************************
*/
package PP20_2;

public class StatsMachineViewer {
	public static void main(String[] arg)
	{
		new StatsMachine();
	}
}

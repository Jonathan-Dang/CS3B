package PP9_5;
import java.util.ArrayList;
import java.util.Date;

import problem4.Daily;
import problem4.Monthly;
import problem4.Onetime;

public class AppointmentBook {
	private ArrayList<Daily> _daily;
	private ArrayList<Monthly> _monthly;
	private ArrayList<Onetime> _onetime;
	private static String[] months = {"Jan" ,"Feb" ,"Mar" ,"Apr" ,"May" ,"Jun" ,"Jul" ,"Aug" ,"Sept" ,"Oct" ,"Nov" ,"Dec"};
	private static String[] day = {"Mon" ,"Tues" ,"Wed" ,"Thurs" ,"Fri" ,"Sat" ,"Sun"};
	
	public AppointmentBook()
	{
		_daily = new ArrayList<Daily>();
		_monthly = new ArrayList<Monthly>();
		_onetime = new ArrayList<Onetime>();
	}
	
	public ArrayList<Daily> getDaily()
	{
		ArrayList<Daily> ret = new ArrayList<Daily>();
		for(int i = 0; i < _daily.size();i++)
		{
			ret.add(_daily.get(i));
		}
		return ret;
	}
	
	public ArrayList<Monthly> getMonthly()
	{
		ArrayList<Monthly> ret = new ArrayList<Monthly>();
		for(int i = 0; i < _monthly.size(); i++)
		{
			ret.add(_monthly.get(i));
		}
		return ret;
	}
	
	public ArrayList<Onetime> getOneTime()
	{
		ArrayList<Onetime> ret = new ArrayList<Onetime>();
		for(int i = 0; i < _onetime.size(); i++)
		{
			ret.add(_onetime.get(i));
		}
		return ret;
	}
	
	public void removeAppointment(String type, String description, int year, int month, int day)
	{
		String upper = type.toUpperCase();
		upper = upper.replace(" ", "");
		@SuppressWarnings("deprecation")
		Date _d = new Date(year,month - 1,day);
		
		if(upper.compareTo("DAILY") == 0)
		{
			for(int i = 0; i < _daily.size(); i++)
			{
				if(_daily.get(i).getDate().compareTo(_d) == 0 &&
						_daily.get(i).getDescription().contains(description))
				{
					_daily.remove(i);
					break;
				}
			}
		}
		else if(upper.compareTo("MONTHLY") == 0)
		{
			for(int i = 0; i < _monthly.size(); i++)
			{
				if(_monthly.get(i).getDate().compareTo(_d) == 0 &&
						_monthly.get(i).getDescription().contains(description))
				{
					_monthly.remove(i);
					break;
				}
			}
		}
		else if(upper.compareTo("ONETIME") == 0)
		{
			for(int i = 0; i < _onetime.size(); i++)
			{
				if(_onetime.get(i).getDate().compareTo(_d) == 0 &&
						_onetime.get(i).getDescription().contains(description))
				{
					_onetime.remove(i);
					break;
				}
			}
		}
		else
			throw new IllegalArgumentException("Invalid Appointment Type!");
	}
	
	public void addAppointment(String type, String description, int day, int month, int year)
	{
		String upper = type.toUpperCase();
		upper = upper.replace(" ", "");
		Daily _d = null;
		Monthly _m = null;
		Onetime _o = null;
		
		if(upper.compareTo("DAILY") == 0)
		{
			_d = new Daily(year, month, day, description);
		}
		else if(upper.compareTo("MONTHLY") == 0)
		{
			_m = new Monthly(year, month, day, description);
		}
		else if(upper.compareTo("ONETIME") == 0)
		{
			_o = new Onetime(year, month, day, description);
		}
		else
			throw new IllegalArgumentException("Invalid Appointment Type!");
		
		if(_d != null)
		{
			_daily.add(_d);
		}
		else if(_m != null)
		{
			_monthly.add(_m);
		}
		else if(_o != null)
		{
			_onetime.add(_o);
		}
	}
	
	public void displayBook()
	{
		System.out.println("Daily Appointments:");
		for(int i = 0; i < _daily.size(); i++)
		{
			System.out.println("\t" + _daily.get(i).getDescription());
		}
		System.out.println();
		
		System.out.println("Monthly Appointments:");
		for(int i = 0; i < _monthly.size(); i++)
		{
			System.out.println("\t Next Appointment for: " + _monthly.get(i).getDescription() + " Occurs every month starting on "
					+ _monthly.get(i).getDate().getDate());
		}
		System.out.println();
		
		System.out.println("One Time Appointments:");
		for(int i = 0; i < _onetime.size(); i++)
		{
			System.out.println("\t" + _onetime.get(i).getDescription() + " on " + day[_onetime.get(i).getDate().getDay()] + " "
			+ months[_onetime.get(i).getDate().getMonth()] + " " + _onetime.get(i).getDate().getDate() + " " 
			+ _onetime.get(i).getDate().getYear());
		}
		
	}
}

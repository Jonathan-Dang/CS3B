//Author: Jonathan Dang | ZaoJia Zhao
//Project: PP10.19
public class TicTacToeViewer {
	public static void main(String[] arg)
	{
		new TicTacToe();
	}
}

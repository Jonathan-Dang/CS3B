//Author: Jonathan Dang
//Project: PP10.25
package PP10_25;

import javax.swing.JFrame;

public class MovingCarsViewer {
	public static void main(String[] arg)
	{
		JFrame MC = new MovingCars();
		MC.setTitle("Assignment 10.25");
		MC.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		MC.setVisible(true);
	}
}

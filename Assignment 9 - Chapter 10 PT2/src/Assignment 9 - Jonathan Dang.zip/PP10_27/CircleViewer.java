//Author: Jonathan Dang
//Project: PP10.27
package PP10_27;

public class CircleViewer {
	public static void main(String[] arg)
	{
		new CircleFrame();
	}
}

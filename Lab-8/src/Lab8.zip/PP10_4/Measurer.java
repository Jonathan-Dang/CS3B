package PP10_4;

/**
 * Measurer Interface
 * @author Jonathan Dang
 *
 */
public interface Measurer {
	double measure(Object anObject);
}

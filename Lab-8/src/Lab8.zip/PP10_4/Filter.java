package PP10_4;

public interface Filter {
	boolean accept(Object x);
}
